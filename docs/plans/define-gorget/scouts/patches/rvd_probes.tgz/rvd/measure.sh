#!/bin/bash
cd /workspace/gorget/.claude/worktrees/agent-a1b2d7aa82e46e8be
DRIVER=tests/fixtures/self_host_lowerer/driver
LIB=lib
run_driver() {
  local f="$1"
  local out; out=$($DRIVER "$f" $LIB --lir-c 2>/tmp/rvd/_err); local code=$?
  if [ $code -eq 0 ] && [ -n "$out" ]; then
    echo "ACCEPT"
  else
    local e; e=$(grep -oE 'error\[E_[A-Za-z]+\]' /tmp/rvd/_err | head -1)
    echo "REJECT ${e}"
  fi
}
echo "############ REPROS (target holes) ############"
printf "%-26s %-12s %s\n" FIXTURE SELFHOST "(production model)"
declare -A prod=( [repro_6_closure]="REJECT E_UseAfterMove" [repro_7_comprehension]="REJECT E_MoveInLoop" [repro_8_slice_alias]="REJECT E_BorrowConflict" [repro_8b_slice_int]="ACCEPT (RV-E parity)" [repro_9_reinit_both]="ACCEPT" [repro_5_copy_struct]="ACCEPT" )
for f in repro_6_closure repro_7_comprehension repro_8_slice_alias repro_8b_slice_int repro_9_reinit_both repro_5_copy_struct; do
  printf "%-26s %-20s | prod: %s\n" "$f" "$(run_driver /tmp/rvd/$f.gg)" "${prod[$f]}"
done
echo ""
echo "############ GUARDS (over-rejection + true-positive) ############"
declare -A gprod=( [g6_closure_live]=ACCEPT [g7_comp_plain]=ACCEPT [g7_comp_read_enclosing]=ACCEPT [g9_move_one_arm]="REJECT E_DoubleMove" [g9_move_both_arms]="REJECT E_DoubleMove" [g9_reinit_one_arm]="REJECT E_DoubleMove" [g9_reinit_both_arms]=ACCEPT [g9_match_reinit_else]=ACCEPT [g9_match_move_all]="REJECT E_DoubleMove" )
for f in g6_closure_live g7_comp_plain g7_comp_read_enclosing g9_move_one_arm g9_move_both_arms g9_reinit_one_arm g9_reinit_both_arms g9_match_reinit_else g9_match_move_all; do
  printf "%-26s %-20s | prod: %s\n" "$f" "$(run_driver /tmp/rvd/guard/$f.gg)" "${gprod[$f]}"
done
